import React from 'react';

export default function EditorSection(): JSX.Element {
  return (
    <div>
      Editor settings content
    </div>
  );
}
