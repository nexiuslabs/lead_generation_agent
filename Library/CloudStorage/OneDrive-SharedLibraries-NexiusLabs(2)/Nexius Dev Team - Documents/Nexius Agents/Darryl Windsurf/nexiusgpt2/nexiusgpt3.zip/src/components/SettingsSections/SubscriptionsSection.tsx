import React from 'react';

type SubscriptionsSectionProps = {
  showToast: (msg: string) => void;
};

export default function SubscriptionsSection({ showToast }: SubscriptionsSectionProps): JSX.Element {
  return (
    <div>
      {/* Subscriptions settings content */}
    </div>
  );
}
